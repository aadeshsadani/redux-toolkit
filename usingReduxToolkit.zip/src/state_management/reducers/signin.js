const { createSlice } = require("@reduxjs/toolkit");

const signin = createSlice({
    name: 'signin',
    initialState: {
        value: 0
    },
    reducers: {
        
    }
});
